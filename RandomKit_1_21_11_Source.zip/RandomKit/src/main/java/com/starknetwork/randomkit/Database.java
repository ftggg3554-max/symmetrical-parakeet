package com.starknetwork.randomkit;

import org.bukkit.configuration.file.FileConfiguration;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Kit storage + first-join records. SQLite by default (zero setup, bundled with Paper) or MySQL.
 * All queries run on one dedicated thread, so the main thread never waits on the database
 * (except once at startup). Items are stored as Paper's binary item format (one row per slot).
 */
public final class Database {

    public record Row(String part, int slot, byte[] data) {}

    public record RawKit(String key, String name, List<Row> rows) {}

    @FunctionalInterface
    public interface Job {
        void run() throws Exception;
    }

    private final RandomKitPlugin plugin;
    private final boolean mysql;
    private final String url;
    private final String user;
    private final String pass;
    private Connection conn;

    /** UUIDs waiting to be written; flushed in one batch every few seconds (see connect()). */
    private final ConcurrentLinkedQueue<UUID> pendingReceived = new ConcurrentLinkedQueue<>();

    private final ScheduledExecutorService exec = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "RandomKit-DB");
        t.setDaemon(true);
        return t;
    });

    public Database(RandomKitPlugin plugin) {
        this.plugin = plugin;
        FileConfiguration c = plugin.getConfig();
        this.mysql = c.getString("database.type", "sqlite").toLowerCase(Locale.ROOT).equals("mysql");
        if (mysql) {
            String host = c.getString("database.mysql.host", "localhost");
            int port = c.getInt("database.mysql.port", 3306);
            String name = c.getString("database.mysql.database", "randomkit");
            this.url = "jdbc:mysql://" + host + ":" + port + "/" + name
                    + "?useUnicode=true&characterEncoding=utf8&useSSL=false&allowPublicKeyRetrieval=true";
            this.user = c.getString("database.mysql.username", "root");
            this.pass = c.getString("database.mysql.password", "");
        } else {
            File f = new File(plugin.getDataFolder(), c.getString("database.sqlite-file", "kits.db"));
            this.url = "jdbc:sqlite:" + f.getAbsolutePath();
            this.user = null;
            this.pass = null;
        }
    }

    // ---------------------------------------------------------------- connection

    /** Last time the connection was pinged; the ping (a round trip on MySQL) runs at most every 30 s. */
    private long lastCheck;

    private Connection conn() throws SQLException {
        long now = System.currentTimeMillis();
        boolean stale = now - lastCheck > 30_000L;
        if (conn == null || conn.isClosed() || (stale && !conn.isValid(2))) {
            closeQuietly();
            conn = mysql ? DriverManager.getConnection(url, user, pass) : DriverManager.getConnection(url);
        }
        if (stale) lastCheck = now;
        return conn;
    }

    private void closeQuietly() {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ignored) {
            }
            conn = null;
        }
    }

    /** Opens the connection and creates the tables. Call once on enable. */
    public synchronized void connect() throws SQLException {
        plugin.getDataFolder().mkdirs();
        try {
            Class.forName(mysql ? "com.mysql.cj.jdbc.Driver" : "org.sqlite.JDBC");
        } catch (ClassNotFoundException ignored) {
        }
        Connection c = conn();
        String blob = mysql ? "MEDIUMBLOB" : "BLOB";
        try (Statement st = c.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS randomkit_kits ("
                    + "kit_key VARCHAR(64) NOT NULL PRIMARY KEY, "
                    + "kit_name VARCHAR(64) NOT NULL)");
            st.executeUpdate("CREATE TABLE IF NOT EXISTS randomkit_items ("
                    + "kit_key VARCHAR(64) NOT NULL, "
                    + "part VARCHAR(16) NOT NULL, "
                    + "slot INT NOT NULL, "
                    + "item_data " + blob + " NOT NULL, "
                    + "PRIMARY KEY (kit_key, part, slot))");
            // Players who already got their first-join kit. Created automatically if missing.
            st.executeUpdate("CREATE TABLE IF NOT EXISTS randomkit_received ("
                    + "player_uuid CHAR(36) NOT NULL PRIMARY KEY)");
        }
        // One batched write every 5s instead of one write per new player.
        exec.scheduleWithFixedDelay(() -> {
            try {
                flushReceived();
            } catch (Throwable t) { // a periodic task dies silently on an exception, so never let one escape
                plugin.getLogger().severe("Database error (received flush): " + t.getMessage());
            }
        }, 5, 5, TimeUnit.SECONDS);
    }

    public boolean isMysql() {
        return mysql;
    }

    public String type() {
        return mysql ? "MySQL" : "SQLite";
    }

    // ---------------------------------------------------------------- queries (run off the main thread)

    public synchronized Map<String, RawKit> loadAll() throws SQLException {
        Connection c = conn();
        Map<String, String> names = new LinkedHashMap<>();
        try (Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT kit_key, kit_name FROM randomkit_kits ORDER BY kit_name")) {
            while (rs.next()) names.put(rs.getString(1), rs.getString(2));
        }
        Map<String, List<Row>> rows = new HashMap<>();
        try (Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT kit_key, part, slot, item_data FROM randomkit_items")) {
            while (rs.next()) {
                rows.computeIfAbsent(rs.getString(1), k -> new ArrayList<>())
                        .add(new Row(rs.getString(2), rs.getInt(3), rs.getBytes(4)));
            }
        }
        Map<String, RawKit> out = new LinkedHashMap<>();
        names.forEach((key, name) -> out.put(key, new RawKit(key, name, rows.getOrDefault(key, List.of()))));
        return out;
    }

    /** Replaces a kit (create or update) in one transaction. */
    public synchronized void saveKit(RawKit kit) throws SQLException {
        Connection c = conn();
        c.setAutoCommit(false);
        try {
            deleteRows(c, kit.key());
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO randomkit_kits (kit_key, kit_name) VALUES (?, ?)")) {
                ps.setString(1, kit.key());
                ps.setString(2, kit.name());
                ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "INSERT INTO randomkit_items (kit_key, part, slot, item_data) VALUES (?, ?, ?, ?)")) {
                for (Row r : kit.rows()) {
                    ps.setString(1, kit.key());
                    ps.setString(2, r.part());
                    ps.setInt(3, r.slot());
                    ps.setBytes(4, r.data());
                    ps.addBatch();
                }
                ps.executeBatch();
            }
            c.commit();
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }

    public synchronized void deleteKit(String key) throws SQLException {
        Connection c = conn();
        c.setAutoCommit(false);
        try {
            deleteRows(c, key);
            c.commit();
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }

    private void deleteRows(Connection c, String key) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("DELETE FROM randomkit_items WHERE kit_key = ?")) {
            ps.setString(1, key);
            ps.executeUpdate();
        }
        try (PreparedStatement ps = c.prepareStatement("DELETE FROM randomkit_kits WHERE kit_key = ?")) {
            ps.setString(1, key);
            ps.executeUpdate();
        }
    }

    // ---------------------------------------------------------------- first-join tracking

    /** Loads every UUID that already got its first-join kit (startup, blocking once). */
    public synchronized Set<UUID> loadReceived() throws SQLException {
        Set<UUID> out = new HashSet<>();
        try (Statement st = conn().createStatement();
             ResultSet rs = st.executeQuery("SELECT player_uuid FROM randomkit_received")) {
            while (rs.next()) {
                try {
                    out.add(UUID.fromString(rs.getString(1)));
                } catch (IllegalArgumentException ignored) {
                }
            }
        }
        return out;
    }

    /** Single-player lookup; only used with MySQL, where another server may have recorded the player. */
    public synchronized boolean hasReceived(UUID id) throws SQLException {
        try (PreparedStatement ps = conn().prepareStatement("SELECT 1 FROM randomkit_received WHERE player_uuid = ?")) {
            ps.setString(1, id.toString());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** Queues a UUID for the next batched write. O(1), never touches the disk. */
    public void queueReceived(UUID id) {
        pendingReceived.add(id);
    }

    /** Inserts UUIDs in one transaction; already-present ones are skipped. */
    public synchronized void insertReceived(Collection<UUID> ids) throws SQLException {
        if (ids.isEmpty()) return;
        Connection c = conn();
        String sql = (mysql ? "INSERT IGNORE" : "INSERT OR IGNORE") + " INTO randomkit_received (player_uuid) VALUES (?)";
        c.setAutoCommit(false);
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            for (UUID id : ids) {
                ps.setString(1, id.toString());
                ps.addBatch();
            }
            ps.executeBatch();
            c.commit();
        } catch (SQLException e) {
            c.rollback();
            throw e;
        } finally {
            c.setAutoCommit(true);
        }
    }

    /** Writes everything queued so far in one batch. On failure the UUIDs go back in the queue. */
    private synchronized void flushReceived() {
        if (pendingReceived.isEmpty()) return;
        List<UUID> batch = new ArrayList<>();
        UUID u;
        while ((u = pendingReceived.poll()) != null) batch.add(u);
        try {
            insertReceived(batch);
        } catch (SQLException e) {
            pendingReceived.addAll(batch); // retry on the next tick
            plugin.getLogger().warning("Could not save first-join records, will retry: " + e.getMessage());
        }
    }

    // ---------------------------------------------------------------- async helpers

    /** Runs a write on the database thread; errors are logged. */
    public void execute(Job job) {
        exec.execute(() -> {
            try {
                job.run();
            } catch (Exception e) {
                plugin.getLogger().severe("Database error: " + e.getMessage());
            }
        });
    }

    /** Runs a read on the database thread, then hands the result to the main thread. */
    public <T> void supply(Callable<T> job, Consumer<T> onMain, Consumer<Exception> onError) {
        exec.execute(() -> {
            try {
                T result = job.call();
                toMain(() -> onMain.accept(result));
            } catch (Exception e) {
                toMain(() -> onError.accept(e));
            }
        });
    }

    private void toMain(Runnable r) {
        if (plugin.isEnabled()) plugin.getServer().getScheduler().runTask(plugin, r);
    }

    /** Waits for pending writes, then closes the connection. */
    public void shutdown() {
        exec.shutdown();
        try {
            exec.awaitTermination(10, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
        flushReceived(); // write whatever is still queued
        synchronized (this) {
            closeQuietly();
        }
    }
}
