package com.starknetwork.randomkit;

import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;

public class KitManager {

    /** Immutable kit. Arrays are pre-built so giving a kit is just a few bulk calls. */
    public static final class Kit {
        private final String name;
        private final String key;
        private final Map<Integer, ItemStack> storage;
        private final Map<Integer, ItemStack> armor;
        private final ItemStack offhand;
        private final ItemStack[] storageArr = new ItemStack[36];
        private final ItemStack[] armorArr = new ItemStack[4];

        Kit(String name, Map<Integer, ItemStack> storage, Map<Integer, ItemStack> armor, ItemStack offhand) {
            this.name = name;
            this.key = name.toLowerCase();
            this.storage = storage;
            this.armor = armor;
            this.offhand = offhand;
            storage.forEach((slot, item) -> {
                if (slot >= 0 && slot < 36) storageArr[slot] = item;
            });
            armor.forEach((slot, item) -> {
                if (slot >= 0 && slot < 4) armorArr[slot] = item;
            });
        }

        public String name() { return name; }
        public Map<Integer, ItemStack> storage() { return storage; }
        public Map<Integer, ItemStack> armor() { return armor; }
        public ItemStack offhand() { return offhand; }
    }

    private final RandomKitPlugin plugin;
    private final Database db;
    /** Old YAML storage; only read once to migrate into the database. */
    private final File legacyFile;
    private final Map<String, Kit> kits = new LinkedHashMap<>();
    private Kit[] kitArray = new Kit[0];

    /** player -> key of the kit they currently hold; usage = how many online players hold each kit. */
    private final Map<UUID, String> lastKit = new HashMap<>();
    private final Map<String, Integer> usage = new HashMap<>();

    public KitManager(RandomKitPlugin plugin, Database db) {
        this.plugin = plugin;
        this.db = db;
        this.legacyFile = new File(plugin.getDataFolder(), "kits.yml");
    }

    // ---------------------------------------------------------------- storage

    /** Startup load (blocking once on enable is fine). Imports the old kits.yml if the database is empty. */
    public void load() {
        try {
            Map<String, Database.RawKit> raw = db.loadAll();
            if (raw.isEmpty() && legacyFile.exists()) {
                importLegacy();
            } else {
                apply(raw);
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("Could not load kits: " + e.getMessage());
        }
    }

    /** Incremented on every reload so an older, still-running staged build cancels itself. */
    private int reloadGen;

    /** Reload: reads the database off the main thread, then builds the kits a little per tick (no lag spike). */
    public void reloadAsync(Consumer<Boolean> done) {
        db.supply(db::loadAll, raw -> applyStaged(raw, done), ex -> {
            plugin.getLogger().severe("Could not reload kits: " + ex.getMessage());
            done.accept(false);
        });
    }

    /**
     * Deserializing items is the only heavy part of a reload. It must stay on the main thread (Bukkit API),
     * so it is spread over several ticks with a ~2 ms budget each, and the new kit set is swapped in at the end.
     */
    private void applyStaged(Map<String, Database.RawKit> raw, Consumer<Boolean> done) {
        final int gen = ++reloadGen;
        final Iterator<Database.RawKit> it = raw.values().iterator();
        final Map<String, Kit> staged = new LinkedHashMap<>();
        new BukkitRunnable() {
            @Override
            public void run() {
                if (gen != reloadGen || !plugin.isEnabled()) {
                    cancel();
                    return;
                }
                final long end = System.nanoTime() + 2_000_000L;
                while (it.hasNext() && System.nanoTime() < end) {
                    Kit kit = build(it.next());
                    staged.put(kit.key, kit);
                }
                if (!it.hasNext()) {
                    cancel();
                    kits.clear();
                    kits.putAll(staged);
                    rebuild();
                    done.accept(true);
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private void apply(Map<String, Database.RawKit> raw) {
        kits.clear();
        for (Database.RawKit r : raw.values()) {
            Kit kit = build(r);
            kits.put(kit.key, kit);
        }
        rebuild();
    }

    private Kit build(Database.RawKit r) {
        Map<Integer, ItemStack> storage = new TreeMap<>();
        Map<Integer, ItemStack> armor = new TreeMap<>();
        ItemStack offhand = null;
        for (Database.Row row : r.rows()) {
            ItemStack it;
            try {
                it = ItemStack.deserializeBytes(row.data());
            } catch (Exception e) {
                plugin.getLogger().warning("Skipped a corrupt item in kit '" + r.name() + "'.");
                continue;
            }
            if (it == null || it.getType() == Material.AIR) continue;
            switch (row.part()) {
                case "storage" -> storage.put(row.slot(), it);
                case "armor" -> armor.put(row.slot(), it);
                case "offhand" -> offhand = it;
                default -> { }
            }
        }
        return new Kit(r.name(), storage, armor, offhand);
    }

    /** Serializes on the main thread (Bukkit API); the database write itself is asynchronous. */
    private Database.RawKit toRaw(Kit kit) {
        List<Database.Row> rows = new ArrayList<>();
        kit.storage.forEach((slot, item) -> rows.add(new Database.Row("storage", slot, item.serializeAsBytes())));
        kit.armor.forEach((slot, item) -> rows.add(new Database.Row("armor", slot, item.serializeAsBytes())));
        if (kit.offhand != null && kit.offhand.getType() != Material.AIR) {
            rows.add(new Database.Row("offhand", 0, kit.offhand.serializeAsBytes()));
        }
        return new Database.RawKit(kit.key, kit.name, rows);
    }

    private void persist(Kit kit) {
        Database.RawKit raw = toRaw(kit);
        db.execute(() -> db.saveKit(raw));
    }

    private void rebuild() {
        kitArray = kits.values().toArray(new Kit[0]);
    }

    // ---- one-time migration from kits.yml

    private void importLegacy() throws SQLException {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(legacyFile);
        ConfigurationSection root = y.getConfigurationSection("kits");
        kits.clear();
        if (root != null) {
            for (String key : root.getKeys(false)) {
                ConfigurationSection s = root.getConfigurationSection(key);
                if (s == null) continue;
                Kit kit = new Kit(key,
                        readMap(s.getConfigurationSection("storage")),
                        readMap(s.getConfigurationSection("armor")),
                        s.getItemStack("offhand"));
                kits.put(kit.key, kit);
            }
        }
        rebuild();
        for (Kit kit : kits.values()) db.saveKit(toRaw(kit));
        File done = new File(legacyFile.getParentFile(), "kits.yml.migrated");
        if (legacyFile.renameTo(done)) {
            plugin.getLogger().info("Imported " + kits.size() + " kit(s) from kits.yml into the database "
                    + "(old file renamed to kits.yml.migrated).");
        }
    }

    private Map<Integer, ItemStack> readMap(ConfigurationSection sec) {
        Map<Integer, ItemStack> map = new TreeMap<>();
        if (sec == null) return map;
        for (String k : sec.getKeys(false)) {
            ItemStack it = sec.getItemStack(k);
            if (it == null || it.getType() == Material.AIR) continue;
            try {
                map.put(Integer.parseInt(k), it);
            } catch (NumberFormatException ignored) {
            }
        }
        return map;
    }

    // ---------------------------------------------------------------- management

    public int size() {
        return kitArray.length;
    }

    public boolean exists(String name) {
        return kits.containsKey(name.toLowerCase());
    }

    public Kit get(String name) {
        return kits.get(name.toLowerCase());
    }

    public Collection<Kit> all() {
        return kits.values();
    }

    public List<String> names() {
        List<String> list = new ArrayList<>(kitArray.length);
        for (Kit k : kitArray) list.add(k.name);
        return list;
    }

    /** Creates or overwrites a kit from the player's current inventory. Returns false if the inventory is empty. */
    public boolean capture(Player player, String name) {
        PlayerInventory inv = player.getInventory();
        Map<Integer, ItemStack> storage = new TreeMap<>();
        Map<Integer, ItemStack> armor = new TreeMap<>();

        for (int i = 0; i < 36; i++) {
            ItemStack it = inv.getItem(i);
            if (it != null && it.getType() != Material.AIR) storage.put(i, it.clone());
        }
        ItemStack[] worn = inv.getArmorContents();
        for (int i = 0; i < worn.length; i++) {
            if (worn[i] != null && worn[i].getType() != Material.AIR) armor.put(i, worn[i].clone());
        }
        ItemStack off = inv.getItemInOffHand();
        ItemStack offClone = (off.getType() == Material.AIR) ? null : off.clone();

        if (storage.isEmpty() && armor.isEmpty() && offClone == null) return false;

        Kit kit = new Kit(name, storage, armor, offClone);
        kits.put(kit.key, kit);
        rebuild();
        persist(kit);
        return true;
    }

    public boolean delete(String name) {
        final String key = name.toLowerCase();
        boolean removed = kits.remove(key) != null;
        if (removed) {
            rebuild();
            db.execute(() -> db.deleteKit(key));
        }
        return removed;
    }

    // ---------------------------------------------------------------- giving

    /** Resets everything except items (items are replaced in bulk by give()). */
    private void resetState(Player player) {
        player.setItemOnCursor(null);
        var effects = player.getActivePotionEffects();
        if (!effects.isEmpty()) {
            for (PotionEffect effect : new ArrayList<>(effects)) {
                player.removePotionEffect(effect.getType());
            }
        }
        AttributeInstance maxHealth = player.getAttribute(Attribute.MAX_HEALTH);
        player.setHealth(maxHealth != null ? maxHealth.getValue() : 20.0);
        player.setFoodLevel(20);
        player.setSaturation(20f);
        player.setFireTicks(0);
        player.setFallDistance(0f);
        player.setLevel(0);
        player.setExp(0f);
    }

    /** Full clean + kit. Bulk-sets all 41 slots (storage, armor, offhand), which also wipes the old items. */
    public void give(Player player, Kit kit) {
        resetState(player);
        PlayerInventory inv = player.getInventory();
        inv.setStorageContents(kit.storageArr); // Bukkit copies items internally, no cloning needed
        inv.setArmorContents(kit.armorArr);
        inv.setItemInOffHand(kit.offhand);
        inv.setHeldItemSlot(0);
        assign(player.getUniqueId(), kit.key);
        player.updateInventory();
    }

    private void assign(UUID id, String key) {
        release(id);
        lastKit.put(id, key);
        usage.merge(key, 1, Integer::sum);
    }

    private void release(UUID id) {
        String old = lastKit.remove(id);
        if (old != null) usage.computeIfPresent(old, (k, v) -> v <= 1 ? null : v - 1);
    }

    public void forget(Player player) {
        release(player.getUniqueId());
    }

    /**
     * Uniformly random kit. Uses rejection sampling (O(1) on average, no list building);
     * falls back to a full scan only when most kits are excluded.
     * - avoid-repeat: never the kit the player had last.
     * - unique-among-players: never a kit another online player holds (relaxed if none are free).
     */
    public Kit pickRandom(Player player) {
        final Kit[] arr = kitArray;
        final int n = arr.length;
        if (n == 0) return null;

        final String own = lastKit.get(player.getUniqueId());
        final boolean avoid = plugin.avoidRepeat && n > 1 && own != null;
        final boolean unique = plugin.uniqueAmongPlayers;
        final ThreadLocalRandom rnd = ThreadLocalRandom.current();

        for (int i = 0; i < 12; i++) {
            Kit k = arr[rnd.nextInt(n)];
            if (isValid(k, own, avoid, unique)) return k;
        }

        List<Kit> pool = new ArrayList<>();
        for (Kit k : arr) if (isValid(k, own, avoid, unique)) pool.add(k);
        if (pool.isEmpty() && unique) {
            for (Kit k : arr) if (isValid(k, own, avoid, false)) pool.add(k);
        }
        if (pool.isEmpty()) return arr[rnd.nextInt(n)];
        return pool.get(rnd.nextInt(pool.size()));
    }

    private boolean isValid(Kit k, String own, boolean avoid, boolean unique) {
        boolean isOwn = k.key.equals(own);
        if (avoid && isOwn) return false;
        if (unique) {
            int heldByOthers = usage.getOrDefault(k.key, 0) - (isOwn ? 1 : 0);
            if (heldByOthers > 0) return false;
        }
        return true;
    }

    public void giveRandom(Player player) {
        Kit kit = pickRandom(player);
        if (kit == null) return;
        give(player, kit);
    }
}
