package com.starknetwork.randomkit;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class KitListener implements Listener {

    private final RandomKitPlugin plugin;
    private final KitManager kits;
    private final Database db;
    // CACHE: every player who already got their first-join kit. Loaded once from the database on enable,
    // so a join check is just an in-memory lookup. New players are written to the database in batches.
    private final Set<UUID> received = ConcurrentHashMap.newKeySet();

    public KitListener(RandomKitPlugin plugin, KitManager kits, Database db) {
        this.plugin = plugin;
        this.kits = kits;
        this.db = db;
        try {
            received.addAll(db.loadReceived());
        } catch (SQLException ex) {
            plugin.getLogger().severe("Could not load first-join records: " + ex.getMessage());
        }
        migrateLegacyFile();
    }

    /** One-time import of the old received.txt into the database (file is renamed to received.txt.migrated). */
    private void migrateLegacyFile() {
        File legacy = new File(plugin.getDataFolder(), "received.txt");
        if (!legacy.exists()) return;
        try {
            List<UUID> toInsert = new ArrayList<>();
            for (String line : Files.readAllLines(legacy.toPath(), StandardCharsets.UTF_8)) {
                line = line.trim();
                if (line.isEmpty()) continue;
                try {
                    UUID id = UUID.fromString(line);
                    received.add(id);
                    toInsert.add(id);
                } catch (IllegalArgumentException ignored) {
                }
            }
            db.insertReceived(toInsert);
            File done = new File(legacy.getParentFile(), "received.txt.migrated");
            if (legacy.renameTo(done)) {
                plugin.getLogger().info("Imported " + toInsert.size()
                        + " first-join record(s) from received.txt into the database.");
            }
        } catch (IOException | SQLException ex) {
            plugin.getLogger().warning("Could not import received.txt (it will be retried next start): " + ex.getMessage());
        }
    }

    /** Gives the first-join kit once and records the player (cache now, database in the next batch). */
    private void grantFirstKit(Player p, UUID id) {
        if (!p.isOnline() || !received.add(id)) return;
        kits.giveRandom(p);
        db.queueReceived(id);
    }

    // First join ever = kit once. After that, a new kit only comes after death (see onRespawn).
    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        UUID id = p.getUniqueId();
        if (!plugin.giveOnJoin || kits.size() == 0) return;
        if (received.contains(id)) return; // cache hit: nothing else to do

        if (db.isMysql()) {
            // Shared database: another server of the network may already have given this player a kit.
            db.supply(() -> db.hasReceived(id), has -> {
                if (has) received.add(id);
                else grantFirstKit(p, id);
            }, ex -> grantFirstKit(p, id));
        } else {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> grantFirstKit(p, id), 2L);
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        if (!plugin.clearDropsOnDeath || kits.size() == 0) return;
        e.setKeepInventory(false);
        e.getDrops().clear();
        e.setKeepLevel(false);
        e.setDroppedExp(0);
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onRespawn(PlayerRespawnEvent e) {
        if (!plugin.giveOnRespawn || kits.size() == 0) return;
        Player p = e.getPlayer();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) kits.giveRandom(p);
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        kits.forget(e.getPlayer());
    }

    // Preview GUI is read-only.
    // These fire on EVERY inventory click on the server, so they must be as cheap as possible.
    // getHolder(false) avoids Paper creating a block-state snapshot for chests/barrels/etc.
    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent e) {
        if (e.getInventory().getHolder(false) instanceof KitCommand.PreviewHolder) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder(false) instanceof KitCommand.PreviewHolder) e.setCancelled(true);
    }
}
